package Asiento;

public enum TipoAsiento {TURISTA, BUSINESS}
