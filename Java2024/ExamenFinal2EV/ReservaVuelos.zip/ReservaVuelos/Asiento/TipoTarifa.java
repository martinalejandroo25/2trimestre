package Asiento;

public enum TipoTarifa {OPTIMA, CONFORT, FLEXIBLE}
