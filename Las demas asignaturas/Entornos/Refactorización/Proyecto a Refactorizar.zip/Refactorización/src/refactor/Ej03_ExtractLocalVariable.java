package refactor;

public class Ej03_ExtractLocalVariable {
	public static void main(String[] args) {
		System.out.println("Aprendiendo a refactorizar!");
	}
}
