package refactor;

public class Ej05_ConvertLocalVbleToField {
	public int calcularArea() {
		int lado = 5;
		return lado * lado;
	}
}
