package refactor;

public class Ej06_ExtractInterface {
	public boolean esMayor() {
		return true;
	}

	public boolean esMenor() {
		return true;
	}

	public boolean esIgual() {
		return true;
	}

}
