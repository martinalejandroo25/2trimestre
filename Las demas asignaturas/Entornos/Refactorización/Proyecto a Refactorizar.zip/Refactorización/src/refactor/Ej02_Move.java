package refactor;

public class Ej02_Move {
	public static int suma(int a, int b) {
		return a + b;
	}
}
