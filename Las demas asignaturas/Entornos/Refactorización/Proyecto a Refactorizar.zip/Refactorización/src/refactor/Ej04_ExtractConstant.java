package refactor;

public class Ej04_ExtractConstant {
	public static void main(String[] args) {
		System.out.println("Aprendiendo a refactorizar!");
	}
}
