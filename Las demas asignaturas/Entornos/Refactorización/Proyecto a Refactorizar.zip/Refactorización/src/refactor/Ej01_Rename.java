package refactor;

public class Ej01_Rename {
	public static void main(String[] args) {
		int a = 12;
		int b = 13;
		int x = 0;
		x = a + b;
		System.out.println("El número de alumnos es " + a);
		System.out.println("El número de alumnas es " + b);
		System.out.println("El total de matrículas es " + x);
	}
}
